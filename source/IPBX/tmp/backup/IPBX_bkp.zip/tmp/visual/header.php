<P align=center>
<TABLE style="WIDTH: 100%; HEIGHT: 5%" border=0 cellSpacing=1 cellPadding=1 
width="90%" bgColor=#6598b7><!-- #778899-->
  <TBODY>
  <TR>
    <TD align=middle><STRONG><FONT color=white size=6>CENTRAL IPBX - 
      2.2.5 </FONT></STRONG>&nbsp; </TD>
    <TD align=right><A href="v_contatos_list.php"><IMG border=0 alt="" 
      src="images/call-center.jpg"></A> </TD></TR></TBODY></TABLE></P>

<?php include './include/teclogica/funcoes_gerais.php'; 
if ($_SESSION["UserID"]!=""){
	echo "<p align=\"center\">".mensagem()."</p>";
}
?>